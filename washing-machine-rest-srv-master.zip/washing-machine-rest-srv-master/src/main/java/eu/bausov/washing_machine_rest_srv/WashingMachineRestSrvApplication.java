package eu.bausov.washing_machine_rest_srv;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WashingMachineRestSrvApplication {

	public static void main(String[] args) {
		SpringApplication.run(WashingMachineRestSrvApplication.class, args);
	}
}
