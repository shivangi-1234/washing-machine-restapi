package eu.bausov.washing_machine_rest_srv.data.repository;

import eu.bausov.washing_machine_rest_srv.domain.program.process.Washing;
import org.springframework.data.repository.CrudRepository;

/**
 * for saving the washing process.
 */
public interface WashingRepository extends CrudRepository<Washing, Long> {
    Washing save(Washing washing);
}
