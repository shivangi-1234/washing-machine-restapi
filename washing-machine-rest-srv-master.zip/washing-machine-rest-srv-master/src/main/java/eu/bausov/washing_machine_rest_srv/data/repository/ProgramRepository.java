package eu.bausov.washing_machine_rest_srv.data.repository;

import eu.bausov.washing_machine_rest_srv.domain.program.Program;
import org.springframework.data.repository.CrudRepository;

/**
 * for saving the current program.
 */
public interface ProgramRepository extends CrudRepository<Program, Long> {
    Program save(Program program);
}
