package eu.bausov.washing_machine_rest_srv.domain;

/**
 * Created by GreenNun on 24/02/2018.
 */
public interface Appliance {
    String getModel();
    String getSerial();
}
