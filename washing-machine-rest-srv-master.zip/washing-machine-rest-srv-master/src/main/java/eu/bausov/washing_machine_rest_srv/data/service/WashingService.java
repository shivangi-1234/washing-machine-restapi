package eu.bausov.washing_machine_rest_srv.data.service;

import eu.bausov.washing_machine_rest_srv.domain.program.process.Washing;

/**
 * for saving the washing.
 */
public interface WashingService {
    Washing save(Washing washing);
}
