package eu.bausov.washing_machine_rest_srv.util;

/**
 * Created by GreenNun on 24/02/2018.
 */
public enum  States {
    WAITING, RUNNING, FINISHED, STOPPED ;
}
